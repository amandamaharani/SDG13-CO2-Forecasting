# CO₂ Emissions Forecasting with Linear Regression
## Individual Machine Learning Project — SDG 13: Climate Action

### 1. Introduction
Climate change is a major global challenge. SDG 13 calls for urgent action to combat climate change and its impacts. Monitoring CO₂ data can help people understand long-term patterns and support evidence-based discussion. This project applies a simple Machine Learning method, Linear Regression, to historical country-level CO₂ data.

### 2. Research question
Can a Linear Regression model use the recent historical trend in the supplied country-level CO₂ dataset to estimate the combined CO₂ value for the next year?

### 3. Dataset
The supplied file, `co2_cons.csv`, contains 192 country/territory rows. It has two identification columns (`geo` and `name`) and annual data columns from 1800 to 2022. The dataset is in wide format, meaning each country is a row and each year is a separate column.

**Data-quality note:** The supplied CSV does not contain a data dictionary or unit description. For that reason, this project reports values in unspecified dataset units. There are 2,315 missing country-year cells. When annual totals are calculated, available values are summed and missing values are skipped; this may underestimate the true combined value.

### 4. Method
1. Load the CSV using pandas.
2. Identify columns containing year labels and convert their values to numeric.
3. Sum available country values for each year to create a combined annual time series.
4. Plot the historical trend.
5. Use `Year` as the input feature (X) and the annual combined CO₂ value as the target (y).
6. Select the most recent 30 years for a short-term model.
7. Train on the earlier years and test on the latest five years chronologically.
8. Evaluate the model using MAE, RMSE, and R².
9. Retrain on the full recent 30-year window and forecast the next year.

### 5. Machine Learning model
Linear Regression finds a straight line that best fits the relationship between year and the target value. It is relatively easy to understand and is a useful starting point for a forecasting project. However, it assumes a linear trend and cannot automatically account for sudden changes.

### 6. Results
- Latest data year: **2022**
- Recent model window: **1993–2022**
- Training period: **1993–2017**
- Test period: **2018–2022**
- Mean Absolute Error (MAE): **1,931.045**
- Root Mean Squared Error (RMSE): **2,107.634**
- R²: **-6.255**
- Next-year estimate (2023): **37,652.160 dataset units**

The negative R² means that, on the five held-out years, the Linear Regression model performed worse than a simple baseline that predicts the average of the test-period values. Therefore, the numerical forecast should be treated cautiously. This is an important evaluation finding and should be reported honestly.

### 7. Conclusion
The project demonstrates how historical data can be cleaned, visualized, and used to train a basic Machine Learning model. The model produces a next-year estimate, but its negative test R² shows that a straight-line trend does not capture the recent fluctuations well. Machine Learning can help analyze climate-related data, but reliable predictions require high-quality data, suitable models, and careful evaluation. Real climate action also depends on changes in policy, technology, energy use, and human behaviour.

### 8. Limitations and improvements
- The original unit and exact accounting definition are not included in the supplied CSV.
- Missing country-year observations may make combined totals incomplete.
- Country coverage and reporting may vary across the historical period.
- Linear Regression cannot model nonlinear patterns or sudden disruptions.
- A future improvement would compare Linear Regression with a baseline forecast and a more flexible time-series model using the same chronological test set.

### 9. References
- United Nations. (n.d.). *Goal 13: Take urgent action to combat climate change and its impacts*. https://sdgs.un.org/goals/goal13
- Gapminder. (n.d.). *Gapminder data*. https://www.gapminder.org/data/
- Scikit-learn. (n.d.). *LinearRegression*. https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- Scikit-learn. (n.d.). *Model evaluation: quantifying the quality of predictions*. https://scikit-learn.org/stable/modules/model_evaluation.html

---

# Presentation Script (approximately 3 minutes)

**Slide 1 — Introduction**

Good morning. My project is called “CO₂ Emissions Forecasting with Linear Regression,” and it is connected to Sustainable Development Goal 13, Climate Action. I wanted to explore whether Machine Learning could use historical CO₂ data to estimate a future value. My research question is: Can a Linear Regression model use recent historical trends to estimate the combined CO₂ value for the next year?

**Slide 2 — Dataset**

I used the provided `co2_cons.csv` dataset. It contains 192 country and territory rows, with yearly data from 1800 to 2022. Each row represents a country, and each year has its own column. I converted the year columns into numeric values and added the available country values for each year to create one combined annual dataset.

One limitation is that the CSV does not state the measurement unit, so I have not assumed a specific unit. Some country-year values are also missing.

**Slide 3 — Method**

I chose Linear Regression because it is a basic and interpretable Machine Learning model. The input, or feature, is the year. The target is the combined CO₂ dataset value for that year. I used the most recent 30 years to focus on the recent trend. I trained the model on earlier years and tested it on the latest five years in that window. This chronological split helps test whether the model can predict later observations using earlier data.

**Slide 4 — Results**

The evaluation produced an MAE of 1,931.05, an RMSE of 2,107.63, and an R-squared value of -6.25. The negative R-squared is important: it means the model performed worse than a simple approach that predicts the average of the test values. This shows that a straight-line model does not capture all the fluctuations in the recent data.

After evaluation, I retrained the model using the full recent 30-year window. Its estimate for 2023 is approximately 37,652.16 dataset units. This is a model estimate, not a guaranteed actual value.

**Slide 5 — Conclusion**

In conclusion, this project showed how Machine Learning can be used to explore climate-related data and create a forecast. However, the evaluation also showed that the model has limitations. CO₂ values can be affected by economic activity, energy sources, government policies, and technological changes. A more advanced model and a dataset with clearly documented units and complete observations could improve the analysis. This project connects to SDG 13 because monitoring emissions trends can support awareness and informed climate action. Thank you.
