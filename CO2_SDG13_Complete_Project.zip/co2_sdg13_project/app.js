async function startDashboard(){
  const res = await fetch("data.json");
  const d = await res.json();
  const fmt = n => Number(n).toLocaleString(undefined,{maximumFractionDigits:2});
  document.getElementById("latestValue").textContent = fmt(d.latest_total);
  document.getElementById("forecastValue").textContent = fmt(d.forecast_value);
  document.getElementById("r2Value").textContent = d.metrics.r2.toFixed(2);
  const r2text = d.metrics.r2 < 0
    ? `R² = ${d.metrics.r2.toFixed(2)}. The model performed worse than the mean-baseline predictor on the five held-out years. Treat the forecast with caution.`
    : `R² = ${d.metrics.r2.toFixed(2)}. The model explains some variation in the held-out years, but future estimates are still uncertain.`;
  document.getElementById("metricInterpretation").textContent = r2text;

  const histYears = d.years;
  const histValues = d.totals;
  const futureYears = d.future_years;
  const futureValues = d.future_values;
  const allYears = histYears.concat(futureYears);
  const histLine = histValues.concat(Array(futureYears.length).fill(null));
  const forecastLine = Array(histYears.length-1).fill(null).concat([histValues[histValues.length-1]],futureValues);
  new Chart(document.getElementById("trendChart"),{
    type:"line",
    data:{labels:allYears,datasets:[
      {label:"Historical combined value",data:histLine,borderColor:"#176b52",backgroundColor:"#176b52",borderWidth:2,pointRadius:0,tension:.18},
      {label:"Linear Regression forecast",data:forecastLine,borderColor:"#d17b42",backgroundColor:"#d17b42",borderDash:[7,5],borderWidth:2,pointRadius:2,tension:0}
    ]},
    options:{responsive:true,maintainAspectRatio:false,interaction:{mode:"index",intersect:false},plugins:{legend:{position:"bottom"}},scales:{x:{ticks:{maxTicksLimit:10}},y:{title:{display:true,text:"Dataset CO₂ value"}}}}
  });

  new Chart(document.getElementById("testChart"),{
    type:"line",
    data:{labels:d.test_years,datasets:[
      {label:"Actual",data:d.test_actual,borderColor:"#176b52",backgroundColor:"#176b52",borderWidth:2,pointRadius:4},
      {label:"Predicted",data:d.test_predicted,borderColor:"#d17b42",backgroundColor:"#d17b42",borderWidth:2,borderDash:[5,4],pointRadius:4}
    ]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom"}},scales:{y:{title:{display:true,text:"Dataset CO₂ value"}}}}
  });

  const select=document.getElementById("countrySelect");
  const countries=d.countries.slice().sort((a,b)=>a.name.localeCompare(b.name));
  countries.forEach(c=>{const o=document.createElement("option");o.value=c.code;o.textContent=c.name;select.appendChild(o);});
  let countryChart;
  function drawCountry(code){
    const c=countries.find(x=>x.code===code);
    const ctx=document.getElementById("countryChart");
    if(countryChart)countryChart.destroy();
    countryChart=new Chart(ctx,{type:"line",data:{labels:c.values.map(v=>v.year),datasets:[{label:c.name+" dataset value",data:c.values.map(v=>v.value),borderColor:"#176b52",backgroundColor:"#176b52",borderWidth:2,pointRadius:0,tension:.15}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{maxTicksLimit:10}},y:{title:{display:true,text:"Dataset CO₂ value"}}}}});
  }
  select.addEventListener("change",()=>drawCountry(select.value));
  const indonesia=countries.find(c=>c.name==="Indonesia");
  select.value=indonesia?indonesia.code:countries[0].code;
  drawCountry(select.value);
}
startDashboard().catch(err=>{console.error(err);document.body.insertAdjacentHTML("beforeend","<p style='padding:20px'>Could not load project data. Please run this site using a local server or GitHub Pages.</p>");});