# CO₂ Emissions Forecasting — SDG 13

A student machine-learning project using Linear Regression to estimate the next year's combined CO₂ dataset value.

## Files
- `index.html`, `app.js`, `data.json`: interactive project website
- `CO2_Emissions_Forecasting_SDG13.ipynb`: Google Colab notebook
- `co2_cons.csv`: supplied dataset
- `Project_Report_and_Presentation_Script.md`: written report and presentation notes

## Run the notebook in Google Colab
1. Upload `CO2_Emissions_Forecasting_SDG13.ipynb` to Google Colab.
2. Run the cells from top to bottom.
3. When prompted, upload `co2_cons.csv`.

## View the website locally
Because the website loads `data.json`, run a local web server from this folder:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Publish free with GitHub Pages
1. Create a new GitHub repository (for example, `co2-sdg13-project`).
2. Upload all files in this folder to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Your website URL will appear in the Pages section.

## Model details (reproducible from the supplied CSV)
- Dataset: 192 country/territory rows; annual columns 1800–2022.
- Feature: calendar year.
- Target: sum of available country values in that year.
- Model: scikit-learn LinearRegression.
- Training window: 1993–2022; test years: 2018, 2019, 2020, 2021, 2022.
- MAE: 1,931.045
- RMSE: 2,107.634
- R²: -6.255
- Next-year estimate: 2023 = 37,652.160 dataset units.

## Important interpretation note
The CSV does not include a data dictionary or unit description. Do not label values as tonnes, kilotonnes, or megatonnes without confirming the original publisher's metadata. Missing values are skipped during annual summation and may cause underestimation. The negative test R² indicates this simple linear model did not beat the mean-baseline predictor on the held-out period. Explain this honestly in the presentation.
